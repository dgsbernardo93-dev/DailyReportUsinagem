# Daily Report - Usinagem (Android)

Projeto Android nativo com o formulário HTML incluído em `app/src/main/assets/index.html`. O formulário abre localmente no aplicativo e não depende do site Netlify para carregar. A internet é necessária para compartilhar/mandar o relatório pelo WhatsApp.

## Como gerar o APK no Android Studio
1. Instale o Android Studio em um computador.
2. Abra a pasta `DailyReportAndroid` como projeto existente.
3. Aguarde a sincronização do Gradle e instale os componentes do Android SDK sugeridos pelo Android Studio (compile SDK 35).
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK aos celulares Android e autorize a instalação deste arquivo quando o Android solicitar.

## Observações
- O projeto foi preparado como fonte; este ambiente não tem Android SDK/Gradle instalados, então o APK não foi compilado nem testado neste ambiente.
- O botão de envio abre o menu de compartilhamento do Android, permitindo selecionar WhatsApp. A seleção de fotos/câmera usa o seletor de arquivos do Android.
- Antes de distribuir para todos os funcionários, compile e teste em pelo menos um celular: envio com uma foto, várias fotos, cancelamento do compartilhamento e formulário após reabertura.
