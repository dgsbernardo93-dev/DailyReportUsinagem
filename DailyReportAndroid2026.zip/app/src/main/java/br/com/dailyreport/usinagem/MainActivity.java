package br.com.dailyreport.usinagem;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 401;
    private Uri pendingCameraUri;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new NativeShare(), "AndroidShare");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent galleryIntent = params.createIntent();
                    Intent chooser = Intent.createChooser(galleryIntent, "Selecionar foto");
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File dir = new File(getCacheDir(), "shared_photos");
                    if (!dir.exists()) dir.mkdirs();
                    File cameraFile = new File(dir, "camera_" + System.currentTimeMillis() + ".jpg");
                    pendingCameraUri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fileprovider", cameraFile);
                    cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, pendingCameraUri);
                    cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
                    startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    pendingCameraUri = null;
                    Toast.makeText(MainActivity.this, "Não foi possível abrir a câmera ou galeria.", Toast.LENGTH_LONG).show();
                    return false;
                }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NativeShare {
        @JavascriptInterface public void share(String text, String jsonPhotos) {
            runOnUiThread(() -> shareReport(text, jsonPhotos));
        }
    }

    private void shareReport(String text, String jsonPhotos) {
        try {
            JSONArray photos = new JSONArray(jsonPhotos == null ? "[]" : jsonPhotos);
            ArrayList<Uri> uris = new ArrayList<>();
            File dir = new File(getCacheDir(), "shared_photos");
            if (!dir.exists()) dir.mkdirs();
            for (int i = 0; i < photos.length(); i++) {
                JSONObject p = photos.getJSONObject(i);
                String name = p.optString("name", "foto_" + i + ".jpg").replaceAll("[^A-Za-z0-9._-]", "_");
                String data = p.optString("data", "");
                int comma = data.indexOf(',');
                if (comma >= 0) data = data.substring(comma + 1);
                byte[] bytes = Base64.decode(data, Base64.DEFAULT);
                File out = new File(dir, System.currentTimeMillis() + "_" + i + "_" + name);
                try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(bytes); }
                Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", out);
                uris.add(uri);
            }
            Intent intent;
            if (uris.size() == 1) {
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                intent.putExtra(Intent.EXTRA_TEXT, text);
                intent.setClipData(ClipData.newUri(getContentResolver(), "Foto do relatório", uris.get(0)));
            } else if (uris.size() > 1) {
                intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                intent.setType("image/*");
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                intent.putExtra(Intent.EXTRA_TEXT, text);
                ClipData clip = ClipData.newUri(getContentResolver(), "Fotos do relatório", uris.get(0));
                for (int i = 1; i < uris.size(); i++) clip.addItem(new ClipData.Item(uris.get(i)));
                intent.setClipData(clip);
            } else {
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text);
            }
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "Enviar Daily Report"));
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao preparar compartilhamento. Tente novamente.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if ((results == null || results.length == 0) && resultCode == RESULT_OK && pendingCameraUri != null) {
                File cameraFile = new File(getCacheDir(), "shared_photos");
                File[] files = cameraFile.listFiles((dir, name) -> name.startsWith("camera_") && name.endsWith(".jpg"));
                if (files != null && files.length > 0) {
                    File newest = files[0];
                    for (File f : files) if (f.lastModified() > newest.lastModified()) newest = f;
                    if (newest.length() > 0) results = new Uri[]{pendingCameraUri};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            pendingCameraUri = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
